﻿import viz
import vizshape
import vizact
import time

viz.go(viz.PROMPT)
#grid = vizshape.addGrid()
room = viz.add('room.WRL')




"""
Kinect Tracker object ID's
These are not actually being using in the script but are to
help anyone who wants to get access to a specific bodypart.
For example to just get a handle to tracking data for the head use:
myHead = vrpn.addTracker( 'Tracker0@localhost', HEAD).
"""

HEAD = 0
NECK = 1
TORSO = 2
WAIST = 3
LEFTCOLLAR = 4
LEFTSHOULD5ER = 5
LEFTELBOW = 6
LEFTWRIST = 7
LEFTHAND = 8
LEFTFINGERTIP = 9
RIGHTCOLLAR = 10
RIGHTSHOULDER = 11
RIGHTELBOW = 12
RIGHTWRIST = 13
RIGHTHAND = 14
RIGHTFINGERTIP = 15
LEFTHIP = 16
LEFTKNEE = 17
LEFTANKLE = 18
LEFTFOOT = 19
RIGHTHIP = 20
RIGHTKNEE = 21
RIGHTANKLE = 22
RIGHTFOOT = 23

#start vrpn
vrpn = viz.addExtension('vrpn7.dle')

RF = vrpn.addTracker('Tracker0@10.10.33.167',RIGHTFOOT)
LF = vrpn.addTracker('Tracker0@10.10.33.167',LEFTFOOT)
RK = vrpn.addTracker('Tracker0@10.10.33.167',RIGHTKNEE)
LK = vrpn.addTracker('Tracker0@10.10.33.167',LEFTKNEE)
#sRA = vizshape.addSphere(radius =.1)
#sLA = vizshape.addSphere(radius =.1)
#sRF = vizshape.addSphere(radius =.1)
#sLF = vizshape.addSphere(radius =.1)
#lRA = viz.link(RA,sRA)
#lLA = viz.link(LA,sLA)
#lLF = viz.link(LF,sLF)
#lRF = viz.link(RF,sRF)


LFvert = 0
RFvert = 0
startLF = 0
startRF = 0
#LKvert = 0
#RKvert = 0
oldTime = time.time()
newTime = time.time()
stepUpL = False
stepUpR = False
tracker = viz.add('intersense.dls')
data = 0
timeElapsed = 0
stepCounter = 0
threshhold = .18
text1 = viz.addText("Stand still")
text1.setPosition(-2.5,1.6,10)
firstStepTime = time.clock()
secondStepTime = time.clock()
stepTimeDif = 0
view = viz.get(viz.MAIN_VIEWPOINT)


#------------------------------------
#  get starting positoins
#------------------------------------
def getStartPos():
	global startLF, startRF, text1
	
	text1.visible(viz.OFF)
	
	startLF = (LF.getPosition())[1]
	startRF = (RF.getPosition())[1]
	text = viz.addText("start walking")
	text.setPosition(-2.5,1.6,10)
	print "Start Left: ", startLF
	print "Start Right: ", startRF
	
	

#------------------------------------
#  get sensor positions
#------------------------------------
def getSensorInfo():
	global LFvert, RFvert, tracker, data, view
	
	LFvert = (LF.getPosition())[1]
	RFvert = (RF.getPosition())[1]
	
	data = tracker.getData()
	data1 = viz.MainView.getPosition()
	view.rotate(data[3]+90,data[4],data[5],'',viz.BODY_ORI)
	#viz.MainView.setPosition(data1[0], data1[1]+1.53, data1[2])
	#viz.MainView.setEuler(data[3], data[4], data[5])


def updateView():
	global RFvert, LFvert, startLF, startRF, threshhold, stepCounter, view
	global firstStepTime, secondStepTime, stepTimeDif, stepUpR, stepUpL

	#view = viz.MainView
	if((RFvert - startRF) > threshhold):
		stepUpR = True
		print "Right is UP!"
	
	if(stepUpR == True):
		if(RFvert <= (startRF+.04)):
			view.move(0,0,.4)
			stepUpR = False
			print "Right is DOWN!"
			if (stepCounter == 2):
				stepCounter = 1
			else:
				stepCounter += 1
			
	if((LFvert - startRF) > threshhold):
		stepUpL = True
		print "Left is UP!"
	
	if(stepUpL == True):
		if(LFvert <= (startLF+.04)):
			view.move(0,0,.4)
			stepUpL = False
			print "Left is DOWN!"
			if (stepCounter == 2):
				stepCounter = 1
			else:
				stepCounter += 1

	
	
#	if(stepCounter == 1):
#		firstStepTime = time.clock()
#	else:
#		secondStepTime = time.clock()
#	
#	if(stepCounter == 2):
#		stepTimeDif = secondStepTime - firstStepTime
		


#def printstuff(rk,lk,rf,lf,tm):
#	rk.write(str(RKvert))
#	rk.write('\n')
#	lk.write(str(LKvert))
#	lk.write('\n')
#	rf.write(str(RFvert))
#	rf.write('\n')
#	lf.write(str(LFvert))
#	lf.write('\n')
#	t = time.clock()
#	tm.write(str(t))
#	tm.write('\n')


def main():
#	rk = open('rightkneeAdj.txt','w')
#	lk = open('leftkneeAdj.txt','w')
#	rf = open('rightfootAdj.txt','w')
#	lf = open('leftfootAdj.txt','w')
#	tm = open('time.txt','w')
	vizact.ontimer2(10, 0, getStartPos)
	vizact.ontimer(.03333,getSensorInfo)
#	vizact.ontimer(.03333,printstuff,rk,lk,rf,lf,tm)
	vizact.ontimer(.03333,updateView)
	

main()


