import viz
import random # for projector flicker
import math

viz.go()

viz.MainView.setEuler([170,0,0])

avatar = viz.add('vcc_male.cfg') # Add a CAL3D based avatar
avatar.state(2) # Activate the walking state

myroom = viz.add('room.wrl')
screen = myroom.getChild('screen') # Get access to a subobject screen in the room

# Add the projected light to the room and translate it to it's correct location
mylight = viz.add('light.WRL')
mylight.setPosition([0,2.25,0])

#this function will make the projector light flicker
def flickerLight():
	# Randomly pick a 0 or a 1
	on = random.choice([0, 1])
	# Set the light's visibility to ON (1) or OFF (0)
	mylight.visible(on)

vizact.ontimer(0.05,flickerLight)

SPEED = 0.5
def moveAvatar():
	t = viz.tick() * SPEED
	  
	# Make avatar walk in circles using a little trig
	newX = -math.cos(t) * 2
	newZ = math.sin(t) * 2
	avatar.setPosition(newX, 0, newZ)
	avatar.setAxisAngle(0,1,0, t/math.pi * 180)

vizact.ontimer(0,moveAvatar)

#Play a movie on the screen
def playMovie():
	
	mymovie = viz.add('mona.mpg')
	mymovie.loop(viz.ON)
	mymovie.play()
	screen.texture(mymovie)	
	
vizact.onkeydown('m', playMovie) 

def moveScreenUp():

	screenup = vizact.moveTo([0,3,0],speed=0.5)
	screen.runAction(screenup)

vizact.onkeydown('u', moveScreenUp)

def moveScreenDown():

	screendown = vizact.moveTo([0,0,0],speed=0.5)
	screen.runAction(screendown)

vizact.onkeydown('d', moveScreenDown)